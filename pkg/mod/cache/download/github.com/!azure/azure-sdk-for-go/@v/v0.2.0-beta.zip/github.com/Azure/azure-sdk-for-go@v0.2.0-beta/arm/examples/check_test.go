package examples

import (
	"testing"
)

func TestCheckName(t *testing.T) {
	checkName("testname01")
}
