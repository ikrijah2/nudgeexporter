package examples

import (
	"testing"
)

func TestCreateAccount(t *testing.T) {
	createAccount("gosdk", "gosdktestname01")
}
