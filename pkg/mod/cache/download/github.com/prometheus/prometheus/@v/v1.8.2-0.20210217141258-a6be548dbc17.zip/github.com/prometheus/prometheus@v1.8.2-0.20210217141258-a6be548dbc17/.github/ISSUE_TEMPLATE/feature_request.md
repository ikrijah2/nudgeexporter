---
name: Feature request
about: Suggest an idea for this project.
title: ''
labels: ''
assignees: ''
---

<!--

    Please do *NOT* ask usage questions in Github issues.

    If your issue is not a feature request or bug report use:
    https://groups.google.com/forum/#!forum/prometheus-users. If
    you are unsure whether you hit a bug, search and ask in the
    mailing list first.

    You can find more information at: https://prometheus.io/community/

-->
## Proposal
**Use case. Why is this important?**

*“Nice to have” is not a good use case. :)*
