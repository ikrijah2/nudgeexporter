// Copyright (c) 2019 The Jaeger Authors.
// Copyright (c) 2017 Uber Technologies, Inc.

package main

import (
	"github.com/jaegertracing/jaeger/examples/hotrod/cmd"
)

func main() {
	cmd.Execute()
}
