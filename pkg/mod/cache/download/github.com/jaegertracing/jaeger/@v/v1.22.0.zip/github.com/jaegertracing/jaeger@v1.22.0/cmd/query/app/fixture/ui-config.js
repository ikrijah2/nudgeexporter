function UIConfig(){
  return {
    x: "y"
  }
}
