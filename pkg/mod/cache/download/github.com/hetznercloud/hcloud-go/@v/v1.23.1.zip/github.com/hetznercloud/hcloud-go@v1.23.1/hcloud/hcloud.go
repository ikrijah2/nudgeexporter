// Package hcloud is a library for the Hetzner Cloud API.
package hcloud

// Version is the library's version following Semantic Versioning.
const Version = "1.23.1"
