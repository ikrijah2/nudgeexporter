Step 7: Congratulations!
========================

At this point your code is merged and you've either fixed a bug or added a new
feature to Gophercloud!

We completely understand that this has been a long process. We appreciate your
patience as well as the time you have taken for working on this. You've made
Gophercloud a better project with your work.
