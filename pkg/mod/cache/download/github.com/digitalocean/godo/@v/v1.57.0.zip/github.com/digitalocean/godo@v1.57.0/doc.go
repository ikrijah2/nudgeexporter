// Package godo is the DigtalOcean API v2 client for Go.
package godo
